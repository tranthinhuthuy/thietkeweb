const express = require("express");

const router = express.Router();

const procedureController =
require("../controllers/procedureController");

router.get(
"/search",
procedureController.searchProcedure
);

module.exports = router;