document.addEventListener("DOMContentLoaded", () => {

loadRatings();

const searchInput =
    document.getElementById("searchInput");

if (searchInput) {

    searchInput.addEventListener(
        "keyup",
        searchRating
    );

}


});

/* ==========================
CHUẨN HÓA TIẾNG VIỆT
========================== */

function removeVietnameseTones(str) {

return (str || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase();

}

/* ==========================
TẢI DANH SÁCH ĐÁNH GIÁ
========================== */

function loadRatings() {

let ratings =
    JSON.parse(
        localStorage.getItem("ratings")
    ) || [];

ratings.reverse();

renderTable(ratings);

updateStatistics(ratings);

}

/* ==========================
THỐNG KÊ
========================== */

function updateStatistics(ratings) {

let fiveStar = 0;
let fourStar = 0;

ratings.forEach(item => {

    if (Number(item.rating) === 5) {

        fiveStar++;

    }

    if (Number(item.rating) === 4) {

        fourStar++;

    }

});

document.getElementById(
    "totalRating"
).textContent =
    ratings.length;

document.getElementById(
    "fiveStar"
).textContent =
    fiveStar;

document.getElementById(
    "fourStar"
).textContent =
    fourStar;

const satisfactionRate =
    ratings.length > 0
        ? Math.round(
            ((fiveStar + fourStar) /
            ratings.length) * 100
        )
        : 0;

document.getElementById(
    "satisfactionRate"
).textContent =
    satisfactionRate + "%";

}

/* ==========================
HIỂN THỊ BẢNG
========================== */

function renderTable(data) {

const table =
    document.getElementById(
        "ratingTable"
    );

table.innerHTML = "";

if (data.length === 0) {

    table.innerHTML = `
    <tr>
        <td colspan="6">
            Chưa có đánh giá nào
        </td>
    </tr>
    `;

    return;

}

data.forEach((item, index) => {

    table.innerHTML += `

    <tr>

        <td>
            ${index + 1}
        </td>

        <td>
            ${item.fullName || ""}
        </td>

        <td>
            ${item.service || ""}
        </td>

        <td>
            ${item.rating || 0} ⭐
        </td>

        <td>
            ${item.date || ""}
        </td>

        <td>

            <button
                class="detail-btn"
                onclick="viewDetail(${JSON.stringify(item).replace(/"/g,'&quot;')})">

                <i class="fa-solid fa-eye"></i>

                Xem

            </button>

        </td>

    </tr>

    `;

});

}

/* ==========================
XEM CHI TIẾT
========================== */

function viewDetail(item) {

document.getElementById(
    "detailContent"
).innerHTML = `

<div class="detail-group">

    <h3>
        THÔNG TIN NGƯỜI ĐÁNH GIÁ
    </h3>

    <p>
        <strong>Họ tên:</strong>
        ${item.fullName || ""}
    </p>

    <p>
        <strong>SĐT:</strong>
        ${item.phone || ""}
    </p>

    <p>
        <strong>Email:</strong>
        ${item.email || "Không có"}
    </p>

</div>

<div class="detail-group">

    <h3>
        KẾT QUẢ ĐÁNH GIÁ
    </h3>

    <p>
        <strong>Dịch vụ sử dụng:</strong>
        ${item.service || ""}
    </p>

    <p>
        <strong>Số sao:</strong>
        ${item.rating || 0} ⭐
    </p>

    <p>
        <strong>Thái độ phục vụ:</strong>
        ${item.attitude || ""}
    </p>

    <p>
        <strong>Thời gian giải quyết:</strong>
        ${item.timeProcess || ""}
    </p>

    <p>
        <strong>Hướng dẫn thủ tục:</strong>
        ${item.guidance || ""}
    </p>

    <p>
        <strong>Mức độ thuận tiện:</strong>
        ${item.convenience || ""}
    </p>

</div>

<div class="detail-group">

    <h3>
        Ý KIẾN GÓP Ý
    </h3>

    <p>
        ${item.comment || "Không có góp ý"}
    </p>

</div>

<div class="detail-group">

    <h3>
        THỜI GIAN ĐÁNH GIÁ
    </h3>

    <p>
        ${item.date || ""}
    </p>

</div>

`;

document.getElementById(
    "detailModal"
).style.display =
    "block";


}

/* ==========================
ĐÓNG POPUP
========================== */

function closeDetail() {

document.getElementById(
    "detailModal"
).style.display =
    "none";


}

/* ==========================
TÌM KIẾM
========================== */

function searchRating() {

const keyword =
    removeVietnameseTones(
        document.getElementById(
            "searchInput"
        ).value.trim()
    );

const ratings =
    JSON.parse(
        localStorage.getItem("ratings")
    ) || [];

const filtered =
    ratings.filter(item => {

        const fullName =
            removeVietnameseTones(
                item.fullName
            );

        const service =
            removeVietnameseTones(
                item.service
            );

        return (
            fullName.includes(keyword) ||
            service.includes(keyword)
        );

    });

renderTable(filtered.reverse());


}

/* ==========================
TỰ ĐỘNG CẬP NHẬT
========================== */

window.addEventListener(
"storage",
loadRatings
);

/* ==========================
ĐÓNG POPUP KHI CLICK NGOÀI
========================== */

window.onclick = function(event) {

const modal =
    document.getElementById(
        "detailModal"
    );

if (event.target === modal) {

    closeDetail();

}

};
