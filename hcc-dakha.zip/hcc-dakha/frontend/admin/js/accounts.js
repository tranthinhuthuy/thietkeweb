let editIndex = -1;

document.addEventListener(
    "DOMContentLoaded",
    function ()
    {
        loadUsers();

        const searchInput =
        document.getElementById(
            "searchUser"
        );

        if(searchInput)
        {
            searchInput.addEventListener(
                "input",
                searchUser
            );

            searchInput.addEventListener(
                "keypress",
                function(e)
                {
                    if(e.key === "Enter")
                    {
                        searchUser();
                    }
                }
            );
        }
    }
);

// =====================
// LOAD USERS
// =====================
function loadUsers()
{
    const users =
    JSON.parse(
        localStorage.getItem("users")
    ) || [];

    const table =
    document.getElementById(
        "userTable"
    );

    if(!table)
    {
        return;
    }

    table.innerHTML = "";

    let totalAdmins = 0;
    let totalMembers = 0;

    // Không có dữ liệu
    if(users.length === 0)
    {
        table.innerHTML = `
        <tr>
            <td colspan="6" class="not-found">
                Chưa có tài khoản nào
            </td>
        </tr>
        `;

        const totalUsers =
        document.getElementById(
            "totalUsers"
        );

        const totalAdminsElement =
        document.getElementById(
            "totalAdmins"
        );

        const totalMembersElement =
        document.getElementById(
            "totalMembers"
        );

        if(totalUsers)
        {
            totalUsers.textContent = "0";
        }

        if(totalAdminsElement)
        {
            totalAdminsElement.textContent = "0";
        }

        if(totalMembersElement)
        {
            totalMembersElement.textContent = "0";
        }

        return;
    }

    users.forEach(
        (user,index)=>
        {
            if(user.role === "admin")
            {
                totalAdmins++;
            }
            else
            {
                totalMembers++;
            }

            table.innerHTML += `
            <tr>

                <td>${user.fullName || ""}</td>

                <td>${user.username || ""}</td>

                <td>${user.email || ""}</td>

                <td>${user.phone || ""}</td>

                <td>
                    ${
                        user.role === "admin"
                        ? "Quản trị viên"
                        : "Người dùng"
                    }
                </td>

                <td>

                    <button
                        type="button"
                        class="btn-edit"
                        onclick="editUser(${index})">

                        <i class="fa-solid fa-pen"></i>

                    </button>

                    <button
                        type="button"
                        class="btn-delete"
                        onclick="deleteUser(${index})">

                        <i class="fa-solid fa-trash"></i>

                    </button>

                </td>

            </tr>
            `;
        }
    );

    const totalUsers =
    document.getElementById(
        "totalUsers"
    );

    if(totalUsers)
    {
        totalUsers.textContent =
        users.length;
    }

    const totalAdminsElement =
    document.getElementById(
        "totalAdmins"
    );

    if(totalAdminsElement)
    {
        totalAdminsElement.textContent =
        totalAdmins;
    }

    const totalMembersElement =
    document.getElementById(
        "totalMembers"
    );

    if(totalMembersElement)
    {
        totalMembersElement.textContent =
        totalMembers;
    }
}

// =====================
// MỞ POPUP THÊM TÀI KHOẢN
// =====================

function openUserModal()
{
    // Xóa dữ liệu cũ trên form
    clearForm();

    // Chế độ thêm mới
    editIndex = -1;

    // Đổi tiêu đề popup
    document.getElementById(
        "modalTitle"
    ).textContent =
    "Thêm tài khoản mới";

    // Đổi nút thành Lưu tài khoản
    const saveBtn =
    document.querySelector(
        ".save-btn"
    );

    if(saveBtn)
    {
        saveBtn.innerHTML = `
            <i class="fa-solid fa-floppy-disk"></i>
            Lưu tài khoản
        `;
    }

    // Hiển thị popup
    const modal =
    document.getElementById(
        "userModal"
    );

    if(!modal)
    {
        console.error(
            "Không tìm thấy userModal"
        );
        return;
    }

    modal.style.display =
    "flex";

    modal.style.justifyContent =
    "center";

    modal.style.alignItems =
    "center";

    // Focus vào ô họ tên
    const fullNameInput =
    document.getElementById(
        "fullName"
    );

    if(fullNameInput)
    {
        setTimeout(
            () =>
            fullNameInput.focus(),
            100
        );
    }
}
// =====================
// ĐÓNG POPUP
// =====================

function closeUserModal()
{
    document.getElementById(
        "userModal"
    ).style.display =
    "none";

    clearForm();
}

// =====================
// LƯU USER
// =====================

function saveUser()
{
    const fullName =
    document.getElementById("fullName")
    .value.trim();

    const username =
    document.getElementById("username")
    .value.trim();

    const email =
    document.getElementById("email")
    .value.trim();

    const phone =
    document.getElementById("phone")
    .value.trim();

    const password =
    document.getElementById("password")
    .value.trim();

    const role =
    document.getElementById("role")
    .value;

    // =====================
    // KIỂM TRA BẮT BUỘC
    // =====================

    if(
        fullName === "" ||
        username === ""
    )
    {
        alert(
            "Vui lòng nhập đầy đủ các trường bắt buộc (*)"
        );
        return;
    }

    // =====================
    // THÊM MỚI => BẮT BUỘC MẬT KHẨU
    // =====================

    if(
        editIndex === -1 &&
        password === ""
    )
    {
        alert(
            "Vui lòng nhập mật khẩu."
        );
        return;
    }

    // =====================
    // KIỂM TRA ĐỘ MẠNH MẬT KHẨU
    // =====================

    if(password !== "")
    {
        const strongPassword =
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;

        if(
            !strongPassword.test(password)
        )
        {
            alert(
                "Mật khẩu phải có ít nhất 8 ký tự, gồm chữ hoa, chữ thường và số."
            );
            return;
        }
    }

    // =====================
    // KIỂM TRA EMAIL
    // =====================

    if(email !== "")
    {
        const emailRegex =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if(
            !emailRegex.test(email)
        )
        {
            alert(
                "Email không hợp lệ!"
            );
            return;
        }
    }

    // =====================
    // KIỂM TRA SĐT
    // =====================

    if(phone !== "")
    {
        const phoneRegex =
        /^(0|\+84)[0-9]{9,10}$/;

        if(
            !phoneRegex.test(phone)
        )
        {
            alert(
                "Số điện thoại không hợp lệ!"
            );
            return;
        }
    }

    // =====================
    // LẤY DANH SÁCH USER
    // =====================

    let users =
    JSON.parse(
        localStorage.getItem("users")
    ) || [];

    // =====================
    // USERNAME TRÙNG
    // =====================

    const duplicateUser =
    users.find(
        (u,i) =>
        u.username &&
        u.username.toLowerCase() ===
        username.toLowerCase() &&
        i !== editIndex
    );

    if(duplicateUser)
    {
        alert(
            "Tên đăng nhập đã tồn tại!"
        );
        return;
    }

    // =====================
    // EMAIL TRÙNG
    // =====================

    if(email !== "")
    {
        const duplicateEmail =
        users.find(
            (u,i) =>
            u.email &&
            u.email.toLowerCase() ===
            email.toLowerCase() &&
            i !== editIndex
        );

        if(duplicateEmail)
        {
            alert(
                "Email đã tồn tại!"
            );
            return;
        }
    }

    // =====================
    // SĐT TRÙNG
    // =====================

    if(phone !== "")
    {
        const duplicatePhone =
        users.find(
            (u,i) =>
            u.phone === phone &&
            i !== editIndex
        );

        if(duplicatePhone)
        {
            alert(
                "Số điện thoại đã tồn tại!"
            );
            return;
        }
    }

    // =====================
    // THÊM MỚI
    // =====================

    if(editIndex === -1)
    {
        const userData = {

            fullName,
            username,
            email,
            phone,
            password,
            role,

            status: "active",

            loginFail: 0,

            lockUntil: null,

            createdAt:
            new Date()
            .toLocaleString("vi-VN")
        };

        users.unshift(userData);

        alert(
            "Thêm tài khoản thành công!"
        );
    }

    // =====================
    // CẬP NHẬT
    // =====================

    else
    {
        const oldUser =
        users[editIndex];

        if(!oldUser)
        {
            alert(
                "Không tìm thấy tài khoản!"
            );
            return;
        }

        users[editIndex] = {

            ...oldUser,

            fullName,
            username,
            email,
            phone,
            role,

            // Nếu nhập mật khẩu mới
            // thì cập nhật
            // nếu bỏ trống thì giữ nguyên

            password:
            password !== ""
            ? password
            : oldUser.password,

            updatedAt:
            new Date()
            .toLocaleString("vi-VN")
        };

        alert(
            "Cập nhật tài khoản thành công!"
        );

        editIndex = -1;
    }

    // =====================
    // LƯU LOCALSTORAGE
    // =====================

    localStorage.setItem(
        "users",
        JSON.stringify(users)
    );

    console.log(
        "Danh sách user sau khi lưu:",
        users
    );

    // =====================
    // RESET GIAO DIỆN
    // =====================

    closeUserModal();

    loadUsers();

    searchUser();
}

// =====================
// SỬA USER
// =====================

function editUser(index)
{
    const users =
    JSON.parse(
        localStorage.getItem(
            "users"
        )
    ) || [];

    const user =
    users[index];

    if(!user)
    {
        alert(
            "Không tìm thấy tài khoản!"
        );
        return;
    }

    // Đổ dữ liệu lên form

    document.getElementById(
        "fullName"
    ).value =
    user.fullName || "";

    document.getElementById(
        "username"
    ).value =
    user.username || "";

    document.getElementById(
        "email"
    ).value =
    user.email || "";

    document.getElementById(
        "phone"
    ).value =
    user.phone || "";

    // Không hiện mật khẩu cũ
    document.getElementById(
        "password"
    ).value = "";

    document.getElementById(
        "role"
    ).value =
    user.role || "user";

    // Lưu vị trí đang sửa

    editIndex = index;

    // Đổi tiêu đề popup

    document.getElementById(
        "modalTitle"
    ).textContent =
    "Chỉnh sửa tài khoản";

    // Đổi text nút lưu thành cập nhật

    const saveBtn =
    document.querySelector(
        ".save-btn"
    );

    if(saveBtn)
    {
        saveBtn.innerHTML = `
            <i class="fa-solid fa-floppy-disk"></i>
            Cập nhật tài khoản
        `;
    }

    // Hiển thị popup

    const modal =
    document.getElementById(
        "userModal"
    );

    modal.style.display =
    "flex";

    modal.style.justifyContent =
    "center";

    modal.style.alignItems =
    "center";
}



// =====================
// XÓA USER
// =====================

function deleteUser(index)
{
    let users =
    JSON.parse(
        localStorage.getItem(
            "users"
        )
    ) || [];

    const user =
    users[index];

    if(!user)
    {
        alert(
            "Không tìm thấy tài khoản!"
        );
        return;
    }

    // Không cho xóa admin cuối cùng
    if(user.role === "admin")
    {
        const adminCount =
        users.filter(
            u => u.role === "admin"
        ).length;

        if(adminCount <= 1)
        {
            alert(
                "Không thể xóa admin cuối cùng!"
            );
            return;
        }
    }

    if(
        !confirm(
            `Bạn có chắc muốn xóa tài khoản "${user.username}" ?`
        )
    )
    {
        return;
    }

    users.splice(
        index,
        1
    );

    localStorage.setItem(
        "users",
        JSON.stringify(users)
    );

    loadUsers();

    searchUser();

    alert(
        "Đã xóa tài khoản thành công!"
    );
}

// =====================
// XÓA FORM
// =====================

function clearForm()
{
    document.getElementById(
        "fullName"
    ).value = "";

    document.getElementById(
        "username"
    ).value = "";

    document.getElementById(
        "email"
    ).value = "";

    document.getElementById(
        "phone"
    ).value = "";

    document.getElementById(
        "password"
    ).value = "";

    document.getElementById(
        "role"
    ).value = "user";

    editIndex = -1;
}

// =====================
// BỎ DẤU TIẾNG VIỆT
// =====================

function removeVietnameseTones(str)
{
    return (str || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g,"")
    .replace(/đ/g,"d")
    .replace(/Đ/g,"D")
    .toLowerCase();
}

// =====================
// TÌM KIẾM
// =====================

function searchUser()
{
    const keyword =
    removeVietnameseTones(
        document
        .getElementById(
            "searchUser"
        )
        .value
        .trim()
    );

    const rows =
    document.querySelectorAll(
        "#userTable tr"
    );

    let found = false;

    rows.forEach(row =>
    {
        const text =
        removeVietnameseTones(
            row.innerText
        );

        if(
            keyword === "" ||
            text.includes(keyword)
        )
        {
            row.style.display = "";
            found = true;
        }
        else
        {
            row.style.display = "none";
        }
    });

    const message =
    document.getElementById(
        "searchMessage"
    );

    if(message)
    {
        if(
            keyword !== "" &&
            !found
        )
        {
            message.textContent =
            "Không tìm thấy tài khoản!";
        }
        else
        {
            message.textContent = "";
        }
    }
}

// =====================
// ĐÓNG POPUP NGOÀI
// =====================

window.onclick =
function(event)
{
    const modal =
    document.getElementById(
        "userModal"
    );

    if(
        event.target === modal
    )
    {
        closeUserModal();
    }
};

// =====================
// ESC ĐÓNG POPUP
// =====================

document.addEventListener(
    "keydown",
    function(event)
    {
        if(
            event.key === "Escape"
        )
        {
            closeUserModal();
        }
    }
);