let editingId = null;
// ==========================
// KHỞI TẠO
// ==========================

document.addEventListener(
"DOMContentLoaded",
function(){

    loadProcedures();


    const searchInput =
    document.getElementById(
        "searchInput"
    );


    if(searchInput){

        searchInput.addEventListener(
            "input",
            searchProcedure
        );

        searchInput.addEventListener(
            "keypress",
            function(e){

                if(e.key === "Enter"){

                    searchProcedure();

                }

            }
        );

    }

});

// ==========================
// STORAGE
// ==========================

function getProcedures(){

    return JSON.parse(
        localStorage.getItem(
            "procedures"
        )
    ) || [];

}

function saveProcedures(data){

    localStorage.setItem(
        "procedures",
        JSON.stringify(data)
    );

}

// ==========================
// LOAD
// ==========================

function loadProcedures(){
const data =
getProcedures();

renderTable(data);
updateStatistics(data);

}

// ==========================
// HIỂN THỊ BẢNG
// ==========================

function renderTable(data){

const table =
document.getElementById(
    "procedureTable"
);


if(!table)
return;

if(data.length===0){


table.innerHTML=`

<tr>

<td colspan="7"
style="text-align:center">

Chưa có thủ tục nào

</td>

</tr>

`;

return;
}

let html="";

data.forEach(
(item,index)=>{


html+=`

<tr>


<td>
${index+1}
</td>


<td>
${item.name}
</td>

<td>
${item.field}
</td>

<td>
${item.time}
</td>

<td>
${item.agency}
</td>

<td>
${item.date}
</td>

<td>

<button
class="edit-btn"
onclick="editProcedure(${item.id})">

<i class="fa-solid fa-pen"></i>

</button>

<button
class="delete-btn"
onclick="deleteProcedure(${item.id})">

<i class="fa-solid fa-trash"></i>

</button>

</td>

</tr>
`;


});

table.innerHTML=html;

}

// ==========================
// THỐNG KÊ
// ==========================

function updateStatistics(data){

document.getElementById(
"totalProcedure"
).textContent=data.length;

let ho=0;
let dat=0;
let chung=0;

data.forEach(item=>{


if(item.field==="Hộ tịch")
ho++;


if(item.field==="Đất đai")
dat++;


if(item.field==="Chứng thực")
chung++;


});


document.getElementById(
"hoTichCount"
).textContent=ho;


document.getElementById(
"datDaiCount"
).textContent=dat;

document.getElementById(
"chungThucCount"
).textContent=chung;


}

// ==========================
// MỞ FORM
// ==========================

function openProcedureForm(){

    clearForm();

    const modal =
        document.getElementById("procedureFormModal");

    modal.style.display = "flex";
    modal.style.justifyContent = "center";
    modal.style.alignItems = "center";
}

// ==========================
// ĐÓNG FORM
// ==========================


function closeProcedureForm(){

document.getElementById(
"procedureFormModal"
).style.display="none";


clearForm();

}

// ==========================
// THÊM + SỬA
// ==========================

function addProcedure() {

    const name =
        document.getElementById("procedureName").value.trim();

    const field =
        document.getElementById("procedureField").value;

    const time =
        document.getElementById("procedureTime").value.trim();

    const fee =
        document.getElementById("procedureFee").value.trim();

    const agency =
        document.getElementById("procedureAgency").value.trim();

    const documents =
        document.getElementById("procedureDocuments").value.trim();

    const description =
        document.getElementById("procedureDescription").value.trim();

    if (
        name === "" ||
        time === "" ||
        agency === ""
    ) {
        alert("Vui lòng nhập đầy đủ thông tin bắt buộc");
        return;
    }

    let data = getProcedures();

    if (editingId) {

        const item =
            data.find(x => x.id === editingId);

        if (item) {

            item.name = name;
            item.field = field;
            item.time = time;
            item.fee = fee;
            item.agency = agency;
            item.documents = documents;
            item.description = description;
            item.date =
                new Date().toLocaleDateString("vi-VN");

        }

        alert("Cập nhật thủ tục thành công!");

    } else {

        data.push({
            id: Date.now(),
            name,
            field,
            time,
            fee,
            agency,
            documents,
            description,
            date:
                new Date().toLocaleDateString("vi-VN")
        });

        alert("Thêm thủ tục thành công!");
    }

    saveProcedures(data);

    closeProcedureForm();

    loadProcedures();
}
// ==========================
// SỬA
// ==========================

function editProcedure(id) {

    const data = getProcedures();

    const item =
        data.find(x => x.id === id);

    if (!item) return;

    editingId = id;

    document.getElementById("procedureName").value =
        item.name || "";

    document.getElementById("procedureField").value =
        item.field || "";

    document.getElementById("procedureTime").value =
        item.time || "";

    document.getElementById("procedureFee").value =
        item.fee || "";

    document.getElementById("procedureAgency").value =
        item.agency || "";

    document.getElementById("procedureDocuments").value =
        item.documents || "";

    document.getElementById("procedureDescription").value =
        item.description || "";

    document.getElementById("formTitle").innerHTML =
        `<i class="fa-solid fa-pen"></i> Chỉnh sửa thủ tục hành chính`;

    const btn =
        document.querySelector(".form-actions .add-btn");

    if (btn) {

        btn.innerHTML =
            `<i class="fa-solid fa-save"></i> Cập nhật thủ tục`;

    }

    document.getElementById(
        "procedureFormModal"
    ).style.display = "flex";
}

// ==========================
// XÓA
// ==========================

function deleteProcedure(id){

if(
!confirm(
"Bạn có chắc muốn xóa thủ tục này?"
)
)
return;

let data =
getProcedures();

data =
data.filter(
x=>x.id!==id
);

saveProcedures(data);

loadProcedures();

}

// ==========================
// TÌM KIẾM
// ==========================

function searchProcedure(){

    console.log("Đang tìm kiếm...");

    const input =
    document.getElementById(
        "searchInput"
    );

    if(!input){
        console.error(
            "Không tìm thấy ô tìm kiếm!"
        );
        return;
    }

    const keyword =
    removeVietnameseTones(
        input.value.trim()
    );

    const data =
    getProcedures();

    console.log(
        "Từ khóa:",
        keyword
    );

    console.log(
        "Dữ liệu:",
        data
    );

    // Nếu ô tìm kiếm trống
    if(keyword === ""){

        renderTable(data);

        return;
    }

    const result =
    data.filter(item => {

        const name =
        removeVietnameseTones(
            item.name || ""
        );

        const field =
        removeVietnameseTones(
            item.field || ""
        );

        const agency =
        removeVietnameseTones(
            item.agency || ""
        );

        const time =
        removeVietnameseTones(
            item.time || ""
        );

        const fee =
        removeVietnameseTones(
            item.fee || ""
        );

        const documents =
        removeVietnameseTones(
            item.documents || ""
        );

        const description =
        removeVietnameseTones(
            item.description || ""
        );

        return (

            name.includes(keyword) ||

            field.includes(keyword) ||

            agency.includes(keyword) ||

            time.includes(keyword) ||

            fee.includes(keyword) ||

            documents.includes(keyword) ||

            description.includes(keyword)

        );

    });

    console.log(
        "Kết quả tìm kiếm:",
        result
    );

    // Không tìm thấy
    if(result.length === 0){

        document.getElementById(
            "procedureTable"
        ).innerHTML = `
            <tr>
                <td colspan="7"
                    class="not-found">
                    Không tìm thấy thủ tục phù hợp
                </td>
            </tr>
        `;

        return;
    }

    renderTable(result);

}
// ==========================
// RESET FORM
// ==========================
function clearForm() {

    document.getElementById("procedureName").value = "";
    document.getElementById("procedureTime").value = "";
    document.getElementById("procedureFee").value = "";
    document.getElementById("procedureAgency").value = "";
    document.getElementById("procedureDocuments").value = "";
    document.getElementById("procedureDescription").value = "";

    document.getElementById(
        "procedureField"
    ).selectedIndex = 0;

    editingId = null;

    const btn =
        document.querySelector(".form-actions .add-btn");

    if (btn) {

        btn.innerHTML =
            `<i class="fa-solid fa-floppy-disk"></i> Lưu thủ tục`;

    }

    const title =
        document.getElementById("formTitle");

    if (title) {

        title.innerHTML =
            `<i class="fa-solid fa-file-circle-plus"></i> Thêm thủ tục hành chính`;

    }
}
// ==========================
// BỎ DẤU
// ==========================

function removeVietnameseTones(str){


return (str||"")

.normalize("NFD")

.replace(
/[\u0300-\u036f]/g,
""
)

.replace(
/đ/g,
"d"
)

.replace(
/Đ/g,
"D"
)

.toLowerCase();


}

// ==========================
// ĐÓNG KHI BẤM NGOÀI
// ==========================


window.onclick=function(e){


const modal =
document.getElementById(
"procedureFormModal"
);

if(
e.target===modal
){

closeProcedureForm();

}

}

// ESC

document.addEventListener(
"keydown",
function(e){


if(e.key==="Escape"){

closeProcedureForm();

}


});