// Danh sách biểu mẫu

const forms = [
    "Đơn đăng ký khai sinh",
    "Đơn đăng ký khai tử",
    "Đơn đăng ký kết hôn",
    "Đơn xác nhận nơi cư trú",
    "Đơn xác nhận tình trạng hôn nhân",
    "Đơn đăng ký biến động đất đai",
    "Đơn cấp Giấy chứng nhận quyền sử dụng đất",
    "Đơn xác nhận hộ nghèo",
    "Đơn đề nghị hưởng trợ cấp bảo trợ xã hội",
    "Đơn tố cáo"
];

const input =
document.getElementById("searchInput");

const suggestions =
document.getElementById("suggestions");


// Hàm bỏ dấu tiếng Việt

function removeVietnameseTones(str)
{
    return str
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/đ/g, "d")
        .replace(/Đ/g, "D")
        .toLowerCase();
}


// Tìm kiếm khi gõ

input.addEventListener("keyup", () =>
{
    const keyword =
    removeVietnameseTones(
        input.value.trim()
    );

    if(keyword === "")
    {
        suggestions.innerHTML = "";
        suggestions.style.display = "none";
        return;
    }

    const result =
    forms.filter(item =>
        removeVietnameseTones(item)
        .includes(keyword)
    );

    suggestions.innerHTML = "";

    if(result.length === 0)
    {
        suggestions.innerHTML =
        `
        <div class="suggestion-item">
            Không tìm thấy kết quả
        </div>
        `;

        suggestions.style.display = "block";
        return;
    }

    result.forEach(item =>
    {
        const div =
        document.createElement("div");

        div.className =
        "suggestion-item";

        div.innerText = item;

        div.onclick = () =>
        {
            input.value = item;
            suggestions.style.display = "none";
        };

        suggestions.appendChild(div);
    });

    suggestions.style.display = "block";
});

// Ẩn gợi ý khi click ra ngoài

document.addEventListener("click", (e) =>
{
    if(
        !input.contains(e.target) &&
        !suggestions.contains(e.target)
    )
    {
        suggestions.style.display = "none";
    }
});